#!/bin/bash
redis-cli FLUSHALL
