#########################
#
#	READ ME!
#
#########################

Docker-Compose and Docker File are working BUT
at the moment there is no connection to the AsteriskDB from inside Docker

Please use TMUX or Screen to run python src/app.py


